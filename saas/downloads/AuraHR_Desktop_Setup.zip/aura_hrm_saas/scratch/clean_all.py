import os
import shutil
import sqlite3

print("==================================================")
print("[+] STARTING COMPLETE CACHE & DATA CLEANUP...")
print("==================================================")

# 1. Clean uploads folder
uploads_dir = 'uploads'
if os.path.exists(uploads_dir):
    count_files = 0
    for f in os.listdir(uploads_dir):
        fp = os.path.join(uploads_dir, f)
        if os.path.isfile(fp):
            try:
                os.remove(fp)
                count_files += 1
            except Exception as e:
                print(f"Error removing {f}: {e}")
    print(f"[OK] Removed {count_files} uploaded files from /uploads directory.")

# 2. Clean Pycache & .pyc
pycache_count = 0
for root, dirs, files in os.walk('.'):
    for d in dirs:
        if d == '__pycache__':
            shutil.rmtree(os.path.join(root, d), ignore_errors=True)
            pycache_count += 1
    for f in files:
        if f.endswith('.pyc') or f.endswith('.pyo'):
            try:
                os.remove(os.path.join(root, f))
            except:
                pass
print(f"[OK] Cleared {pycache_count} __pycache__ directories and .pyc files.")

# 3. Clean Databases (Activity logs, Candidates, Manual Entries)
db_dir = 'databases'
if os.path.exists(db_dir):
    for db_name in os.listdir(db_dir):
        if db_name.endswith('.db'):
            db_path = os.path.join(db_dir, db_name)
            try:
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
                tables = [r[0] for r in cursor.fetchall() if not r[0].startswith('sqlite_')]
                
                for t in tables:
                    # Keep core structure and default seed users/companies, clear manual activity logs & candidates & requests
                    if t in ['activity_logs', 'candidates', 'requests', 'leave_requests', 'payroll', 'weekend', 'increment']:
                        cursor.execute(f"DELETE FROM {t}")
                        print(f"  - Cleared table '{t}' in {db_name}")
                
                conn.commit()
                conn.close()
            except Exception as e:
                print(f"Notice cleaning {db_name}: {e}")

print("==================================================")
print("[OK] ALL CACHE, UPLOADED CVs, ACTIVITY LOGS & MANUAL ENTRIES CLEARED SUCCESSFULLY!")
print("==================================================")
