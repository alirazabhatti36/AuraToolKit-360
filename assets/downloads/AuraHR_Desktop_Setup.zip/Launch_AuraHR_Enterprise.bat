@echo off
title AuraHR 360 Enterprise - Local Desktop App
color 0b
echo =====================================================================
echo           AURA HR 360 ENTERPRISE - DESKTOP LOCAL SYSTEM
echo =====================================================================
echo.
echo Checking Python runtime environment...
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH.
    echo Please install Python 3.10+ from https://www.python.org/downloads/
    echo Be sure to check 'Add Python to PATH' during installation.
    echo.
    pause
    exit /b 1
)

echo [1/2] Verifying dependencies...
pip install -r requirements.txt --quiet

echo [2/2] Launching dedicated Desktop Window...
python desktop_launcher.py

echo.
echo AuraHR Enterprise closed.
pause
